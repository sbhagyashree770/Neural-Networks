# Shinde, Bhagyashree
# 1001-552-353
# 2018-09-24
# Assignment-02-02
import numpy as np
from sklearn.metrics import confusion_matrix
import scipy.misc
import matplotlib.pylab as plt

# This module calculates the activation function
# This code belongs to the code provided by professor for assignment1 . The code has been reused and modified as per requirements.
def calculate_activation_function(weights,training_input,type):
	net_value = np.dot(weights,training_input)
	(nNeuron, nSamples) = net_value.shape
	# print(nNeuron)
	# print(nSamples)
	activation = np.zeros((nNeuron, nSamples))
	if type == "Symmetrical Hard limit":
		# print(len(self.net_value))
		for i in range(nNeuron):
			for j in range(nSamples):
				if net_value[i][j] >= 0:
					activation[i][j] = 1
				else:
					activation[i][j] = -1

	elif type == "Linear":
		activation = net_value
	elif type == "RELU":
		net_value[net_value<0]=0
		activation = net_value
	elif type =="Hyperbolic Tangent":
		activation =np.tanh(net_value)
	return activation

