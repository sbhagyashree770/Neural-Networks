# Shinde, Bhagyashree
# 1001-552-353
# 2018-09-24
# Assignment-02-02
import numpy as np
# This module calculates the activation function
# This code belongs to the code provided by professor for assignment1 . The code has been reused and modified as per requirements.
def calculate_activation_function(weight,bias,input_array1,input_array2,type='Symmetrical Hardlimit'):
	net_value = weight[0] * input_array1+ weight[1] * input_array2+ bias
	if type == 'Symmetrical Hardlimit':
		if net_value >= 0:
			activation = 1
		else:
			activation = -1
	elif type == "Linear":
		activation = net_value
	elif type == "RELU":
		net_value[net_value<0]=0
		activation = net_value
	elif type =="Hyperbolic Tangent":
		activation =np.tanh(net_value)
	return activation
