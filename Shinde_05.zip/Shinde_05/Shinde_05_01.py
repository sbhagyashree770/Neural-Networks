# Shinde, Bhagyashree
# 1001-552-353
# 2018-10-29
# Assignment-05-01
from sklearn.cluster import AgglomerativeClustering
import sys
import os
import pandas as pd
import numpy as np

import scipy.misc
import matplotlib.pyplot as plt
import tensorflow as tf
import create_2d_data_set as data_2d

if sys.version_info[0] < 3:
    import Tkinter as tk
else:
    import tkinter as tk
from tkinter import simpledialog
from tkinter import filedialog
import matplotlib
from mpl_toolkits.mplot3d import Axes3D

matplotlib.use('TkAgg')
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.backends.backend_agg import FigureCanvasAgg
import matplotlib.pyplot as plto
import numpy as np
import matplotlib as mpl
from matplotlib.ticker import LinearLocator, FormatStrFormatter
import matplotlib.backends.tkagg as tkagg
import matplotlib.pyplot as plt


class MainWindow(tk.Tk):
    """
    This class creates and controls the main window frames and widgets
    Bhagyashree Shinde 2018_06_03
    The code for this class is from the sample code provided by professor
    Farhad Kamangar in Assignment1
    """

    def __init__(self, debug_print_flag=False):
        tk.Tk.__init__(self)
        self.debug_print_flag = debug_print_flag
        self.master_frame = tk.Frame(self)
        self.master_frame.grid(row=0, column=0, sticky=tk.N + tk.E + tk.S + tk.W)
        self.rowconfigure(0, weight=1, minsize=500)
        self.columnconfigure(0, weight=1, minsize=500)
        # set the properties of the row and columns in the master frame
        # self.master_frame.rowconfigure(0, weight=1,uniform='xx')
        # self.master_frame.rowconfigure(1, weight=1, uniform='xx')
        # self.master_frame.rowconfigure(2, weight=10, minsize=400, uniform='xx')
        self.master_frame.rowconfigure(3, weight=1, minsize=10, uniform='xx')
        self.master_frame.columnconfigure(0, weight=1, minsize=200, uniform='xx')
        # self.master_frame.columnconfigure(1, weight=1, minsize=200, uniform='xx')
        # create all the widgets
        self.menu_bar = MenuBar(self, self.master_frame, background='orange')
        self.tool_bar = ToolBar(self, self.master_frame)
        self.left_frame = tk.Frame(self.master_frame)
        self.right_frame = tk.Frame(self.master_frame)
        self.status_bar = StatusBar(self, self.master_frame, bd=1, relief=tk.SUNKEN)
        # Arrange the widgets
        self.menu_bar.grid(row=0, columnspan=2, sticky=tk.N + tk.E + tk.S + tk.W)
        self.tool_bar.grid(row=1, columnspan=2, sticky=tk.N + tk.E + tk.S + tk.W)
        self.left_frame.grid(row=2, column=0, sticky=tk.N + tk.E + tk.S + tk.W)
        # self.right_frame.grid(row=2, column=1, sticky=tk.N + tk.E + tk.S + tk.W)
        self.status_bar.grid(row=3, columnspan=2, sticky=tk.N + tk.E + tk.S + tk.W)
        # Create an object for plotting graphs in the left frame
        self.display_activation_functions = LeftFrame(self, self.left_frame, debug_print_flag=self.debug_print_flag)
        # Create an object for displaying graphics in the right frame
        # self.display_graphics = RightFrame(self, self.right_frame, debug_print_flag=self.debug_print_flag)


class MenuBar(tk.Frame):
    # The code for this class is from the sample code provided by professor
    #  Farhad Kamangar in Assignment1

    def __init__(self, root, master, *args, **kwargs):
        tk.Frame.__init__(self, master, *args, **kwargs)
        self.root = root
        self.menu = tk.Menu(self.root)
        root.config(menu=self.menu)
        self.file_menu = tk.Menu(self.menu)
        self.menu.add_cascade(label="File", menu=self.file_menu)
        self.file_menu.add_command(label="New", command=self.menu_callback)
        self.file_menu.add_command(label="Open...", command=self.menu_callback)
        self.file_menu.add_separator()
        self.file_menu.add_command(label="Exit", command=self.menu_callback)
        self.dummy_menu = tk.Menu(self.menu)
        self.menu.add_cascade(label="Dummy", menu=self.dummy_menu)
        self.dummy_menu.add_command(label="Item1", command=self.menu_item1_callback)
        self.dummy_menu.add_command(label="Item2", command=self.menu_item2_callback)
        self.help_menu = tk.Menu(self.menu)
        self.menu.add_cascade(label="Help", menu=self.help_menu)
        self.help_menu.add_command(label="About...", command=self.menu_help_callback)

    def menu_callback(self):
        self.root.status_bar.set('%s', "called the menu callback!")

    def menu_help_callback(self):
        self.root.status_bar.set('%s', "called the help menu callback!")

    def menu_item1_callback(self):
        self.root.status_bar.set('%s', "called item1 callback!")

    def menu_item2_callback(self):
        self.root.status_bar.set('%s', "called item2 callback!")


class ToolBar(tk.Frame):
    # The code for this class is from the sample code provided by professor
    #  Farhad Kamangar in Assignment1
    def __init__(self, root, master, *args, **kwargs):
        tk.Frame.__init__(self, master, *args, **kwargs)
        self.root = root
        self.master = master
        self.var_filename = tk.StringVar()
        self.var_filename.set('')
        self.ask_for_string = tk.Button(self, text="Ask for a string", command=self.ask_for_string)
        self.ask_for_string.grid(row=0, column=1)
        self.file_dialog_button = tk.Button(self, text="Open File Dialog", fg="blue", command=self.browse_file)
        self.file_dialog_button.grid(row=0, column=2)
        self.open_dialog_button = tk.Button(self, text="Open Dialog", fg="blue", command=self.open_dialog_callback)
        self.open_dialog_button.grid(row=0, column=3)

    def say_hi(self):
        self.root.status_bar.set('%s', "hi there, everyone!")

    def ask_for_string(self):
        s = simpledialog.askstring('My Dialog', 'Please enter a string')
        self.root.status_bar.set('%s', s)

    def ask_for_float(self):
        f = float(simpledialog.askfloat('My Dialog', 'Please enter a float'))
        self.root.status_bar.set('%s', str(f))

    def browse_file(self):
        self.var_filename.set(tk.filedialog.askopenfilename(filetypes=[("allfiles", "*"), ("pythonfiles", "*.txt")]))
        filename = self.var_filename.get()
        self.root.status_bar.set('%s', filename)

    def open_dialog_callback(self):
        d = MyDialog(self.root)
        self.root.status_bar.set('%s', "mydialog_callback pressed. Returned results: " + str(d.result))

    def button2_callback(self):
        self.root.status_bar.set('%s', 'button2 pressed.')

    def toolbar_draw_callback(self):
        self.root.display_graphics.create_graphic_objects()
        self.root.status_bar.set('%s', "called the draw callback!")

    def toolbar_callback(self):
        self.root.status_bar.set('%s', "called the toolbar callback!")


class MyDialog(tk.simpledialog.Dialog):
    # The code for this class is from the sample code provided by professor
    #  Farhad Kamangar in Assignment1
    def body(self, parent):
        tk.Label(parent, text="Integer:").grid(row=0, sticky=tk.W)
        tk.Label(parent, text="Float:").grid(row=1, column=0, sticky=tk.W)
        tk.Label(parent, text="String:").grid(row=1, column=2, sticky=tk.W)
        self.e1 = tk.Entry(parent)
        self.e1.insert(0, 0)
        self.e2 = tk.Entry(parent)
        self.e2.insert(0, 4.2)
        self.e3 = tk.Entry(parent)
        self.e3.insert(0, 'Default text')
        self.e1.grid(row=0, column=1)
        self.e2.grid(row=1, column=1)
        self.e3.grid(row=1, column=3)
        self.cb = tk.Checkbutton(parent, text="Hardcopy")
        self.cb.grid(row=3, columnspan=2, sticky=tk.W)

    def apply(self):
        try:
            first = int(self.e1.get())
            second = float(self.e2.get())
            third = self.e3.get()
            self.result = first, second, third
        except ValueError:
            tk.tkMessageBox.showwarning("Bad input", "Illegal values, please try again")


class StatusBar(tk.Frame):
    # The code for this class is from the sample code provided by professor
    #  Farhad Kamangar in Assignment1
    def __init__(self, root, master, *args, **kwargs):
        tk.Frame.__init__(self, master, *args, **kwargs)
        self.label = tk.Label(self)
        self.label.grid(row=0, sticky=tk.N + tk.E + tk.S + tk.W)

    def set(self, format, *args):
        self.label.config(text=format % args)
        self.label.update_idletasks()

    def clear(self):
        self.label.config(text="")
        self.label.update_idletasks()


class LeftFrame:
    """
    This class creates and controls the widgets and figures in the left frame which
    are used to display the activation functions.
        Bhagyashree Shinde 2018_06_03
    The code for this class is from the sample code provided by professor
   Farhad Kamangar in Assignment1
   I have modified parts of code according to requirements
    """

    def __init__(self, root, master, debug_print_flag=False):
        self.master = master
        self.root = root
        # self.activation_function = "Symmetrical Hardlimit"
        #########################################################################
        #  Set up the constants and default values
        #########################################################################

        self.lambda_wr = 0.01
        self.no_of_nodes_hidden_layer = 100
        self.no_of_samples = 200
        self.no_of_classes = 4
        self.hidden_layer_transfer_function = "RELU"
        self.type_of_generated_data = "s_curve"
        self.alpha=0.1

        # print("data",self.type_of_generated_data)
        print("fucntion",self.hidden_layer_transfer_function)
        self.input, self.classes = data_2d.generate_data(self.type_of_generated_data, self.no_of_samples,
                                                         self.no_of_classes)
        print("input", self.input.shape)
        # self.W1 = tf.Variable(tf.random_uniform([self.no_of_nodes_hidden_layer,2], -0.001, 0.001), name='W1')
        # self.b1 = tf.Variable(tf.random_uniform([self.no_of_nodes_hidden_layer], -0.001, 0.001), name='b1')
        #
        # # and the weights connecting the hidden layer to the output layer
        #
        # self.W2 = tf.Variable(tf.random_uniform([4, self.no_of_nodes_hidden_layer], -0.001, 0.001), name='W2')
        # self.b2 = tf.Variable(tf.random_uniform([4], -0.001, 0.0001), name='b2')

        #########################################################################
        #  load images
        #########################################################################
        # self.alpha = 0.01
        self.initFunction()

        # self.training_data = np.zeros((self.trainingSize, 2))
        # self.test_data = np.zeros((self.testSize, 2))

        # self.training_input = self.input_data.iloc[0:int(self.training_sample_size*len(self.input_data)/100), :]
        #
        # self.testing_input= self.input_data.iloc[int(self.training_sample_size*len(self.input_data)/100):, :]

        #########################################################################
        #  Set up the plotting frame and controls frame
        #########################################################################
        # self.xmin = 1
        # # self.xmax = self.no_of_iterations
        # self.ymin = 0
        # self.ymax = 2

        master.rowconfigure(0, weight=10, minsize=200)
        master.columnconfigure(0, weight=1)
        self.plot_frame = tk.Frame(self.master, borderwidth=10, relief=tk.SUNKEN)
        self.plot_frame1 = tk.Frame(self.master, borderwidth=10, relief=tk.SUNKEN)
        # self.plot_frame.pack(side="top", fill="both", expand = True)
        self.plot_frame.grid(row=0, column=0, sticky=tk.N + tk.E + tk.S + tk.W)
        self.figure = plt.figure("")
        self.figure1 = plt.figure("")
        # self.plot_frame1.grid(row=0, column=1, sticky=tk.N + tk.E + tk.S + tk.W)
        # self.axes = self.figure.add_axes([0.15, 0.15, 0.6, 0.8])
        # self.axes = self.figure.add_axes()
        #
        self.axes = self.figure.gca()
        # self.axes1 = self.figure1.gca()
        # self.fig, ((self.ax1, self.ax2), (self.ax3, self.ax4)) = plt.subplots(2, 2)
        # self.axes.set_xlabel('Epoch')
        # self.axes.set_ylabel('Error')
        # self.axes.margins(0.5)
        # self.axes.set_title("")
        # plt.xlim(self.xmin, self.xmax)
        # plt.ylim(self.ymin, self.ymax)
        # self.fig.subplots_adjust(top=0.92, left=0.07, right=0.97,hspace=0.3, wspace=0.3)

        # self.canvas = FigureCanvasTkAgg(self.fig, master=self.plot_frame)
        self.canvas = FigureCanvasTkAgg(self.figure, master=self.plot_frame)
        # self.canvas1 = FigureCanvasTkAgg(self.figure1, master=self.plot_frame1)
        self.plot_widget = self.canvas.get_tk_widget().pack(side="top", fill="both", expand=True)
        # self.plot_widget1 = self.canvas1.get_tk_widget().pack(side="top", fill="both", expand=True)
        # self.plot_widget.pack(side="top", fill="both", expand = True)
        # Create a frame to contain all the controls such as sliders, buttons, ...
        self.controls_frame = tk.Frame(self.master)
        self.controls_frame.grid(row=1, column=0, sticky=tk.N + tk.E + tk.S + tk.W)
        #########################################################################
        #  Set up the control widgets such as sliders and selection boxes
        #########################################################################

        # !--------------------------------------- Slider 1-----------------------------!

        self.alpha_slider = tk.Scale(self.controls_frame, variable=tk.DoubleVar(), orient=tk.HORIZONTAL,
                                     from_=0.001, to_=1.0, resolution=0.001, bg="#DDDDDD",
                                     activebackground="#FF0000", highlightcolor="#00FFFF", label="Alpha -learning rate",
                                     command=lambda event: self.alpha_slider_callback())
        self.alpha_slider.set(self.alpha)
        self.alpha_slider.bind("<ButtonRelease-1>", lambda event: self.alpha_slider_callback())
        self.alpha_slider.grid(row=0, column=0, sticky=tk.N + tk.E + tk.S + tk.W)

        # !--------------------------------------- Slider 2-----------------------------!
        self.no_of_nodes_hidden_layer_slider = tk.Scale(self.controls_frame, variable=tk.DoubleVar(),
                                                        orient=tk.HORIZONTAL,
                                                        from_=1, to_=500, resolution=1, bg="#DDDDDD",
                                                        activebackground="#FF0000",
                                                        highlightcolor="#00FFFF",
                                                        label="No of nodes in hidden layer",
                                                        command=lambda
                                                            event: self.no_of_nodes_hidden_layer_slider_callback())
        self.no_of_nodes_hidden_layer_slider.set(self.no_of_nodes_hidden_layer)
        self.no_of_nodes_hidden_layer_slider.bind("<ButtonRelease-1>",
                                                  lambda event: self.no_of_nodes_hidden_layer_slider_callback())
        self.no_of_nodes_hidden_layer_slider.grid(row=0, column=1, sticky=tk.N + tk.E + tk.S + tk.W)

        # !--------------------------------------- Slider 3-----------------------------!
        self.no_of_samples_slider = tk.Scale(self.controls_frame, variable=tk.DoubleVar(), orient=tk.HORIZONTAL,
                                             from_=4,
                                             to_=1000, resolution=1, bg="#DDDDDD", activebackground="#FF0000",
                                             highlightcolor="#00FFFF", label="No of Samples",
                                             command=lambda event: self.no_of_samples_slider_callback())
        self.no_of_samples_slider.set(self.no_of_samples)
        self.no_of_samples_slider.bind("<ButtonRelease-1>", lambda event: self.no_of_samples_slider_callback())
        self.no_of_samples_slider.grid(row=0, column=2, sticky=tk.N + tk.E + tk.S + tk.W)

        # !--------------------------------------- Slider 4-----------------------------!
        self.lambda_slider = tk.Scale(self.controls_frame, variable=tk.DoubleVar(), orient=tk.HORIZONTAL,
                                      from_=0.0, to_=1.0, resolution=0.01, bg="#DDDDDD",
                                      activebackground="#FF0000", highlightcolor="#00FFFF", label="lambda",
                                      command=lambda event: self.lambda_slider_callback())
        self.lambda_slider.set(self.lambda_wr)
        self.lambda_slider.bind("<ButtonRelease-1>", lambda event: self.lambda_slider_callback())
        self.lambda_slider.grid(row=0, column=3, sticky=tk.N + tk.E + tk.S + tk.W)

        # !--------------------------------------- Slider 5-----------------------------!
        self.no_of_classes_slider = tk.Scale(self.controls_frame, variable=tk.DoubleVar(), orient=tk.HORIZONTAL,
                                             from_=2, to_=10, resolution=1, bg="#DDDDDD",
                                             activebackground="#FF0000", highlightcolor="#00FFFF",
                                             label="NO of classes",
                                             command=lambda event: self.no_of_classes_slider_callback())
        self.no_of_classes_slider.set(self.no_of_classes)
        self.no_of_classes_slider.bind("<ButtonRelease-1>", lambda event: self.no_of_classes_slider_callback())
        self.no_of_classes_slider.grid(row=1, column=0, sticky=tk.N + tk.E + tk.S + tk.W)
        #
        #########################################################################
        #  Set up the frame for Button
        #########################################################################

        self.adjust_weights_button = tk.Button(self.controls_frame, text="Adjust Weights(Train)", fg="blue",
                                               command=self.adjust_weights_button_callback)
        self.adjust_weights_button.grid(row=1, column=1)

        self.reset_weights_button = tk.Button(self.controls_frame, text="Reset Weights", fg="blue",
                                              command=self.reset_weights_button_callback)
        self.reset_weights_button.grid(row=1, column=3)

        #########################################################################
        #  Set up the frame for drop down selection
        #########################################################################

        self.hidden_layer_transfer_function = tk.Label(self.controls_frame, text="Hidden Layer Function Type:",
                                                       justify="center")
        self.hidden_layer_transfer_function.grid(row=2, column=0, sticky=tk.N + tk.E + tk.S + tk.W)
        self.hidden_layer_transfer_function_variable = tk.StringVar()
        self.hidden_layer_transfer_function_dropdown = tk.OptionMenu(self.controls_frame,
                                                                     self.hidden_layer_transfer_function_variable,
                                                                     "RELU", "Sigmoid", command=lambda
                event: self.hidden_layer_transfer_function_dropdown_callback())
        self.hidden_layer_transfer_function_variable.set("RELU")
        self.hidden_layer_transfer_function_dropdown.grid(row=2, column=0, sticky=tk.N + tk.E + tk.S + tk.W)

        self.type_of_generated_data = tk.Label(self.controls_frame, text="Type of generated data:", justify="center")
        self.type_of_generated_data.grid(row=2, column=1, sticky=tk.N + tk.E + tk.S + tk.W)
        self.type_of_generated_data_variable = tk.StringVar()
        self.type_of_generated_data_dropdown = tk.OptionMenu(self.controls_frame, self.type_of_generated_data_variable,
                                                             "s_curve", "blobs", "swiss_roll", "moons", command=lambda
                event: self.type_of_generated_data_dropdown_callback())
        self.type_of_generated_data_variable.set(self.type_of_generated_data)
        self.type_of_generated_data_dropdown.grid(row=2, column=1, sticky=tk.N + tk.E + tk.S + tk.W)

        self.canvas.get_tk_widget().bind("<ButtonPress-1>", self.left_mouse_click_callback)
        self.canvas.get_tk_widget().bind("<ButtonPress-1>", self.left_mouse_click_callback)
        self.canvas.get_tk_widget().bind("<ButtonRelease-1>", self.left_mouse_release_callback)
        self.canvas.get_tk_widget().bind("<B1-Motion>", self.left_mouse_down_motion_callback)
        self.canvas.get_tk_widget().bind("<ButtonPress-3>", self.right_mouse_click_callback)
        self.canvas.get_tk_widget().bind("<ButtonRelease-3>", self.right_mouse_release_callback)
        self.canvas.get_tk_widget().bind("<B3-Motion>", self.right_mouse_down_motion_callback)
        self.canvas.get_tk_widget().bind("<Key>", self.key_pressed_callback)
        self.canvas.get_tk_widget().bind("<Up>", self.up_arrow_pressed_callback)
        self.canvas.get_tk_widget().bind("<Down>", self.down_arrow_pressed_callback)
        self.canvas.get_tk_widget().bind("<Right>", self.right_arrow_pressed_callback)
        self.canvas.get_tk_widget().bind("<Left>", self.left_arrow_pressed_callback)
        self.canvas.get_tk_widget().bind("<Shift-Up>", self.shift_up_arrow_pressed_callback)
        self.canvas.get_tk_widget().bind("<Shift-Down>", self.shift_down_arrow_pressed_callback)
        self.canvas.get_tk_widget().bind("<Shift-Right>", self.shift_right_arrow_pressed_callback)
        self.canvas.get_tk_widget().bind("<Shift-Left>", self.shift_left_arrow_pressed_callback)
        self.canvas.get_tk_widget().bind("f", self.f_key_pressed_callback)
        self.canvas.get_tk_widget().bind("b", self.b_key_pressed_callback)

    def key_pressed_callback(self, event):
        self.root.status_bar.set('%s', 'Key pressed')

    def up_arrow_pressed_callback(self, event):
        self.root.status_bar.set('%s', "Up arrow was pressed")

    def down_arrow_pressed_callback(self, event):
        self.root.status_bar.set('%s', "Down arrow was pressed")

    def right_arrow_pressed_callback(self, event):
        self.root.status_bar.set('%s', "Right arrow was pressed")

    def left_arrow_pressed_callback(self, event):
        self.root.status_bar.set('%s', "Left arrow was pressed")

    def shift_up_arrow_pressed_callback(self, event):
        self.root.status_bar.set('%s', "Shift up arrow was pressed")

    def shift_down_arrow_pressed_callback(self, event):
        self.root.status_bar.set('%s', "Shift down arrow was pressed")

    def shift_right_arrow_pressed_callback(self, event):
        self.root.status_bar.set('%s', "Shift right arrow was pressed")

    def shift_left_arrow_pressed_callback(self, event):
        self.root.status_bar.set('%s', "Shift left arrow was pressed")

    def f_key_pressed_callback(self, event):
        self.root.status_bar.set('%s', "f key was pressed")

    def b_key_pressed_callback(self, event):
        self.root.status_bar.set('%s', "b key was pressed")

    def left_mouse_click_callback(self, event):
        self.root.status_bar.set('%s', 'Left mouse button was clicked. ' + 'x=' + str(event.x) + '   y=' + str(
            event.y))
        self.x = event.x
        self.y = event.y
        self.canvas.focus_set()

    def left_mouse_release_callback(self, event):
        self.root.status_bar.set('%s',
                                 'Left mouse button was released. ' + 'x=' + str(event.x) + '   y=' + str(event.y))
        self.x = None
        self.y = None

    def left_mouse_down_motion_callback(self, event):
        self.root.status_bar.set('%s', 'Left mouse down motion. ' + 'x=' + str(event.x) + '   y=' + str(event.y))
        self.x = event.x
        self.y = event.y

    def right_mouse_click_callback(self, event):
        self.root.status_bar.set('%s', 'Right mouse down motion. ' + 'x=' + str(event.x) + '   y=' + str(event.y))
        self.x = event.x
        self.y = event.y

    def right_mouse_release_callback(self, event):
        self.root.status_bar.set('%s',
                                 'Right mouse button was released. ' + 'x=' + str(event.x) + '   y=' + str(event.y))
        self.x = None
        self.y = None

    def right_mouse_down_motion_callback(self, event):
        self.root.status_bar.set('%s', 'Right mouse down motion. ' + 'x=' + str(event.x) + '   y=' + str(event.y))
        self.x = event.x
        self.y = event.y

    def left_mouse_click_callback(self, event):
        self.root.status_bar.set('%s', 'Left mouse button was clicked. ' + 'x=' + str(event.x) + '   y=' + str(
            event.y))
        self.x = event.x
        self.y = event.y

    # self.focus_set()
    def read_csv_as_matrix(self, file_name):
        # Each row of data in the file becomes a row in the matrix
        # So the resulting matrix has dimension [num_samples x sample_dimension]
        data = np.loadtxt(file_name, skiprows=1, delimiter=',', dtype=np.float32)

        return data

    # def normalize_data(self):
    #     data= self.read_csv_as_matrix("stock_data.txt")

    # Below method plots graph for mse and mae xmax and ymax are set on highest mse and mae for better visibility of
    # graph , if u want to s=change it to 2 , it can be done by making changes below

    def generate_data(self):
        self.input, self.classes = data_2d.generate_data(self.type_of_generated_data, self.no_of_samples,
                                                         self.no_of_classes)
        print("input", self.input.shape)

    def plot_graph(self):
        # self.xmin = 1
        # self.xmax = self.no_of_iterations
        # self.ymin = 0
        # self.ymax = 2
        resolution = 100
        self.axes.cla()
        xs = np.linspace(np.min(self.input[:, 0]), np.max(self.input[:, 0]), 100)
        ys = np.linspace(np.min(self.input[:, 1]), np.max(self.input[:, 1]), 100)
        xx, yy = np.meshgrid(xs, ys)
        z = self.session.run([self.zz],
                             feed_dict={self.p: np.transpose(np.append(xx.reshape(1, -1), yy.reshape(1, -1), axis=0)),
                                        self.lr: self.alpha})
        # print("z",z.reshape())
        plt.pcolormesh(xx.reshape(1, -1), yy.reshape(1, -1), z, cmap=plt.cm.Accent)
        # plt.show()
        plt.scatter(xx.reshape(1, -1), yy.reshape(1, -1), c=z)
        # plt.contourf(xx.reshape(1, -1), yy.reshape(1, -1), z, cmap=plt.cm.Accent)
        plt.scatter(self.input[:, 0], self.input[:, 1], c=self.classes, cmap=plt.cm.Accent)

        self.canvas.draw()
        # self.axes = plt.scatter(xx, yy, c=z.reshape((-1)), cmap=plt.cm.Accent)
        # plt.contourf(xx, yy, z.reshape((-1)), cmap=plt.cm.Spectral)
        # plt.scatter(self.input[:, 0], self.input[:, 1], c=self.classes, cmap=plt.cm.Accent)
        # self.canvas.draw()
        # # self.axes1.set_xlim(1,len(mae))
        # self.axes1.plot(np.linspace(1, len(mae),len(mae)), mae, color="blue")
        # self.axes1.set_xlabel('No of Iterations')
        # self.axes1.set_ylabel('Max Absolute Error')
        # self.axes1.set_title("Max Absolute Error-plot")
        # self.canvas1.draw()

    # def no_of_delayed_elements_slider_callback(self):
    #     self.no_of_delayed_elements = self.no_of_delayed_elements_slider.get()
    #     # self.display_activation_function()

    def alpha_slider_callback(self):
        self.alpha = np.float(self.alpha_slider.get())
        # self.display_activation_function()
        self.session.run(tf.global_variables_initializer())

    def no_of_samples_slider_callback(self):
        self.no_of_samples = self.no_of_samples_slider.get()
        self.generate_data()
        self.session.run(tf.global_variables_initializer())

    def lambda_slider_callback(self):
        self.lambda_wr = np.float(self.lambda_slider.get())
        self.session.run(tf.global_variables_initializer())

    def no_of_classes_slider_callback(self):
        self.no_of_classes = self.no_of_classes_slider.get()
        self.generate_data()
        self.session.run(tf.global_variables_initializer())

    def hidden_layer_transfer_function_dropdown_callback(self):
        self.hidden_layer_transfer_function = self.hidden_layer_transfer_function_variable.get()
        print(self.hidden_layer_transfer_function)
        self.session.run(tf.global_variables_initializer())

    def type_of_generated_data_dropdown_callback(self):
        self.type_of_generated_data = self.type_of_generated_data_variable.get()
        self.generate_data()
        self.session.run(tf.global_variables_initializer())

    def no_of_nodes_hidden_layer_slider_callback(self):
        self.no_of_nodes_hidden_layer = self.no_of_nodes_hidden_layer_slider.get()
        self.session.run(tf.global_variables_initializer())

    def reset_weights_button_callback(self):

        self.session.run(tf.global_variables_initializer())
        self.axes.cla()
        plt.scatter(self.input[:, 0], self.input[:, 1], c=self.classes, cmap=plt.cm.Accent)

        self.canvas.draw()

    def initFunction(self):
        self.input, self.classes = data_2d.generate_data(self.type_of_generated_data, self.no_of_samples,
                                                         self.no_of_classes)
        print("input", self.input.shape)

        self.W1 = tf.Variable(tf.random_uniform([self.no_of_nodes_hidden_layer, 2], -0.001, 0.001), name='W1')
        self.b1 = tf.Variable(tf.random_uniform([self.no_of_nodes_hidden_layer, 1], -0.001, 0.001), name='b1')

        # and the weights connecting the hidden layer to the output layer

        self.W2 = tf.Variable(tf.random_uniform([4, self.no_of_nodes_hidden_layer], -0.001, 0.001), name='W2')
        self.b2 = tf.Variable(tf.random_uniform([4, 1], -0.001, 0.001), name='b2')
        self.p = tf.placeholder(dtype=tf.float32)
        self.t = tf.placeholder(dtype=tf.float32)
        self.lr = tf.placeholder(dtype=np.float32)

        self.output_hidden_layer = tf.matmul(self.W1, tf.transpose(self.p)) + self.b1
        print("data type", self.type_of_generated_data)
        print("w1", self.W1.shape)
        print(self.b1)
        print(self.hidden_layer_transfer_function)
        # output_hidden_layer=tf.add(tf.matmul(self.W1,tf.transpose(self.input)),self.b1)

        print("ouput hidden layer", self.output_hidden_layer.shape)
        if self.hidden_layer_transfer_function == "RELU":
            self.activation_output_hidden_layer = tf.nn.relu(self.output_hidden_layer)
        else:
            self.activation_output_hidden_layer = tf.nn.sigmoid(self.output_hidden_layer)

        print("activation hidden", self.activation_output_hidden_layer)
        print(self.activation_output_hidden_layer.shape)
        print("transpose", tf.transpose(self.activation_output_hidden_layer))
        # output_layer=tf.add(tf.matmul(self.W2,np.transpose(activation_output_hidden_layer)),self.b2)

        self.output_layer = tf.matmul(self.W2, self.activation_output_hidden_layer) + self.b2
        print("Output shape", self.output_layer.shape)

        # softmax=
        # print("softmax",softmax.shape)
        # beta1= self.lambda_wr*tf.nn.l2_loss(self.W1)
        # beta2=self.lambda_wr*tf.nn.l2_loss(self.W2)


        self.zz = tf.argmax(tf.nn.softmax(self.output_layer))
        print("zz", self.zz.shape)
        self.labely = tf.one_hot(self.classes, self.no_of_classes)
        self.sft_max = tf.transpose(tf.nn.softmax(self.output_layer, axis=0))
        self.loss = -tf.reduce_mean(
            tf.reduce_sum(self.labely * tf.log(self.sft_max) + (1 - self.labely) * tf.log(1 - self.sft_max), axis=1))
        self.beta1 = tf.reduce_sum(tf.pow(self.W1,2))
        self.beta2 = tf.reduce_sum(tf.pow(self.W2,2))
        self.cross_entropy_loss = tf.add(self.loss,self.lambda_wr*(self.beta1+self.beta2))
        # self.loss = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits_v2(logits=self.output_layer, labels=tf.transpose(labely)))
        # self.celoss=self.loss+self.beta1+beta2
        # optimizer = tf.train.GradientDescentOptimizer(self.alpha).minimize(loss)
        self.dW1, self.dW2, self.db1, self.db2 = tf.gradients(self.cross_entropy_loss, [self.W1, self.W2, self.b1, self.b2])
        # print(dW1)
        self.update_W1 = tf.assign_sub(self.W1, self.alpha * self.dW1)
        self.update_W2 = tf.assign_sub(self.W2, self.alpha * self.dW2)
        self.update_b1 = tf.assign_sub(self.b1, self.alpha * self.db1)
        self.update_b2 = tf.assign_sub(self.b2, self.alpha * self.db2)

        self.session = tf.InteractiveSession()

        self.session.run(tf.global_variables_initializer())

    def adjust_weights_button_callback(self):
        print("lambda",self.lambda_wr)
        print("alpha",self.alpha)
        print("data tpe",self.type_of_generated_data)
        print("function",self.hidden_layer_transfer_function)
        errors = []
        for i in range(10):
            # print("run tf")
            current_error, sft, _, _, _,_ = self.session.run(
                [self.cross_entropy_loss, self.sft_max, self.update_W1, self.update_W2, self.update_b1, self.update_b2],
                feed_dict={self.p: self.input, self.t: self.classes, self.lr: self.alpha})

            # print("output",output.shape)
            # print(current_error)
            print(i)
            print(current_error)
            errors.append(current_error)
            self.plot_graph()
        # print("error",errors)

        # self.zzvv = tf.argmax(tf.nn.softmax(tf.transpose(self.output_layer)), 1)
        # print("zz", self.zz.shape)
        # output=self.session.run((self.output_layer))
        # print(output)
        # plt.suptitle("S Curve", fontsize=20)
        # print(self.input[0][0])
        # print(self.input[199][0])
        # print(self.input[0][1])
        # print(self.input[199][1])
        # print(self.input[:, 0])
        # print(np.max(self.input[:, 1]))

        # print("zz shape",zz.shape)
        # self.axes.cla()
        resolution = 200
        # z=np.asarray(zz)
        # print("z shape", z)
        print("")
        # tf.reshape()

        # def activation_function_dropdown_callback(self):
    #     self.activation_function = self.activation_function_variable.get()
    #     print(self.activation_function)
    #     # self.reinitalize()
    #     # self.train_data_callback()
    #     # self.display_activation_function()

    # def stride_slider_callback(self):
    #     self.stride = self.stride_slider.get()
    #

    # def display_confusion_matrix_callback(self):
    #     activation = Shinde_03_02.calculate_activation_function(self.weights, self.testing_input, self.activation_function)
    #     # Shinde_02_02.display_confusion_matrix(activation,self.testing_target)
    #
    # #     # y_test_non_category = [np.argmax(t) for t in self.testing_target]  #np.argmax(activation[:,:])
    # #     # y_predict_non_category = [np.argmax(t) for t in activation]
    # #     # print(y_test_non_category)
    # #     # print(y_predict_non_category)
    #     y_test_non_category=[]
    #     y_predict_non_category=[]
    #     for j in range(200):
    #         y_predict_non_category.append(np.argmax(activation[:, j]))
    #         y_test_non_category.append(np.argmax(self.testing_target[:, j]))
    #     print("loooppppp")
    #     print(y_predict_non_category)
    #     print(y_test_non_category)
    #
    #     input_array= confusion_matrix(y_test_non_category,y_predict_non_category)
    #     print(input_array)
    #     # self.display_numpy_array_as_table(cnf_matrix)
    #     # display_numpy_array_as_table.display_numpy_array_as_table(input_array)
    # def display_numpy_array_as_table(input_array):
    # This function displays a 1d or 2d numpy array (matrix).
    # Farhad Kamangar Sept. 2018
    # if input_array.ndim == 1:
    #     num_of_columns, = input_array.shape
    #     temp_matrix = input_array.reshape((1, num_of_columns))
    # elif input_array.ndim > 2:
    #     print("Input matrix dimension is greater than 2. Can not display as table")
    #     return
    # else:
    #     temp_matrix = input_array
    # number_of_rows, num_of_columns = temp_matrix.shape
    # plt.figure()
    # # self.axes.cla
    # tb = self.axes.table(cellText=np.round(temp_matrix, 2), loc=(0, 0), cellLoc='center')
    # for cell in tb.properties()['child_artists']:
    #     cell.set_height(1 / number_of_rows)
    #     cell.set_width(1 / num_of_columns)
    #
    # # self.axes = plt.gca()
    # # self.axes.cla()
    #
    # ax = plt.gca()
    # ax.set_xticks([])
    # ax.set_yticks([])
    #
    # self.canvas.draw()
    # plt.show()
    # self.canvas.get_tk_widget().destroy()
    # # self.canvas.draw()
    # plt.show()

    # def random_data_callback(self):
    #     self.data_points_generation()
    #     self.reinitalize()
    #     self.display_activation_function()

    # Method to train data
    # def adjust_weight_callback(self):
    #     gamma=0.5
    #     for i in range(0, 100):
    #
    #             activation = Shinde_03_02.calculate_activation_function(self.weights, self.training_input, self.activation_function)
    #             print(activation)
    #             # print(net_value)
    #             if self.learning_method=='Unsupervised Hebbian rule':
    #                 self.weights=self.weights+self.alpha*np.dot(activation,np.transpose(self.training_input))
    #             elif self.learning_method=='Delta Rule':
    #                 self.weights=self.weights+self.alpha*np.dot((self.training_target-activation),np.transpose(self.training_input))
    #             elif self.learning_method=='Filtered learning(smoothing)':
    #                 self.weights=(1-gamma)*self.weights+self.alpha*np.dot(self.training_target,np.transpose(self.training_input))
    #
    #             activation = Shinde_03_02.calculate_activation_function(self.weights, self.testing_input,
    #                                                                     self.activation_function)
    #             # print(activation)
    #             #this part of the code is referred from link given below
    #             #https://github.com/sami001/NeuralNetworks_UTA/tree/master/Hebbian%20learning%20rules/Saeef_02
    #             sum = 0.0
    #             for j in range(200):
    #
    #                 maxidx1 = np.argmax(activation[:, j])
    #                 maxidx2 = np.argmax(self.testing_target[:, j])
    #
    #                 if maxidx1 == maxidx2:
    #                     sum += 1.0
    #
    #             self.y[i] = (1 - (sum / 200.0)) * 100
    #             print(self.y[i])
    #     self.x = np.arange(self.x_start, self.x_start + 100)
    #
    #     self.x_start += 100
    #
    #     if self.x_start > 1000:
    #         self.axes.cla()
    #         self.x_start = 0
    #     self.display_activation_function()
    #
    # #generates random data_points
    # def data_points_generation(self):
    #     self.data_points = np.random.rand(4,2)  # Create an array of the given shape and populate it with random samples
    #     # print(self.data_points)
    #     self.data_points = (self.data_points * 20) - 10
    #     # print(self.data_points)

    # This method is used for reinitialization of various attributes as it need sto be
    # reinitalized when random data points are plotted
    # def reinitalize(self):
    #     self.xmin = -10
    #     self.xmax = 10
    #     self.ymin = -10
    #     self.ymax = 10
    #     self.input_weight = [1, 1]
    #     self.bias = 0
    #
    #


class RightFrame:
    """
    This class is for creating right frame widgets which are used to draw graphics
    on canvas as well as embedding matplotlib figures in the tkinter.
    Farhad Kamangar 2018_06_03
    """

    def __init__(self, root, master, debug_print_flag=False):
        self.root = root
        self.master = master
        self.debug_print_flag = debug_print_flag
        width_px = root.winfo_screenwidth()
        height_px = root.winfo_screenheight()
        width_mm = root.winfo_screenmmwidth()
        height_mm = root.winfo_screenmmheight()
        # 2.54 cm = in
        width_in = width_mm / 25.4
        height_in = height_mm / 25.4
        width_dpi = width_px / width_in
        height_dpi = height_px / height_in
        if self.debug_print_flag:
            print('Width: %i px, Height: %i px' % (width_px, height_px))
            print('Width: %i mm, Height: %i mm' % (width_mm, height_mm))
            print('Width: %f in, Height: %f in' % (width_in, height_in))
            print('Width: %f dpi, Height: %f dpi' % (width_dpi, height_dpi))
        # self.canvas = self.master.canvas
        #########################################################################
        #  Set up the plotting frame and controls frame
        #########################################################################
        master.rowconfigure(0, weight=10, minsize=200)
        master.columnconfigure(0, weight=1)
        master.rowconfigure(1, weight=1, minsize=20)
        self.right_frame = tk.Frame(self.master, borderwidth=10, relief='sunken')
        self.right_frame.grid(row=0, column=0, columnspan=1, sticky=tk.N + tk.E + tk.S + tk.W)
        self.matplotlib_width_pixel = self.right_frame.winfo_width()
        self.matplotlib_height_pixel = self.right_frame.winfo_height()
        # set up the frame which contains controls such as sliders and buttons
        self.controls_frame = tk.Frame(self.master)
        self.controls_frame.grid(row=1, column=0, sticky=tk.N + tk.E + tk.S + tk.W)
        self.controls_frame.rowconfigure(1, weight=1, minsize=20)
        self.draw_button = tk.Button(self.controls_frame, text="Draw", fg="red", width=16,
                                     command=self.graphics_draw_callback)
        self.plot_2d_button = tk.Button(self.controls_frame, text="Plot 2D", fg="red", width=16,
                                        command=self.matplotlib_plot_2d_callback)
        self.plot_3d_button = tk.Button(self.controls_frame, text="Plot 3D", fg="red", width=16,
                                        command=self.matplotlib_plot_3d_callback)
        self.draw_button.grid(row=0, column=0)
        self.plot_2d_button.grid(row=0, column=1)
        self.plot_3d_button.grid(row=0, column=2)
        self.right_frame.update()
        self.canvas = tk.Canvas(self.right_frame, relief='ridge', width=self.right_frame.winfo_width() - 110,
                                height=self.right_frame.winfo_height())
        if self.debug_print_flag:
            print("Right frame width, right frame height : ", self.right_frame.winfo_width(),
                  self.right_frame.winfo_height())
        self.canvas.rowconfigure(0, weight=1)
        self.canvas.columnconfigure(0, weight=1)
        self.canvas.grid(row=0, column=0, sticky=tk.N + tk.E + tk.S + tk.W)
        self.canvas.bind("<ButtonPress-1>", self.left_mouse_click_callback)
        self.canvas.bind("<ButtonRelease-1>", self.left_mouse_release_callback)
        self.canvas.bind("<B1-Motion>", self.left_mouse_down_motion_callback)
        self.canvas.bind("<ButtonPress-3>", self.right_mouse_click_callback)
        self.canvas.bind("<ButtonRelease-3>", self.right_mouse_release_callback)
        self.canvas.bind("<B3-Motion>", self.right_mouse_down_motion_callback)
        self.canvas.bind("<Key>", self.key_pressed_callback)
        self.canvas.bind("<Up>", self.up_arrow_pressed_callback)
        self.canvas.bind("<Down>", self.down_arrow_pressed_callback)
        self.canvas.bind("<Right>", self.right_arrow_pressed_callback)
        self.canvas.bind("<Left>", self.left_arrow_pressed_callback)
        self.canvas.bind("<Shift-Up>", self.shift_up_arrow_pressed_callback)
        self.canvas.bind("<Shift-Down>", self.shift_down_arrow_pressed_callback)
        self.canvas.bind("<Shift-Right>", self.shift_right_arrow_pressed_callback)
        self.canvas.bind("<Shift-Left>", self.shift_left_arrow_pressed_callback)
        self.canvas.bind("f", self.f_key_pressed_callback)
        self.canvas.bind("b", self.b_key_pressed_callback)
        # Create a figure for 2d plotting
        self.matplotlib_2d_fig = mpl.figure.Figure()
        # self.matplotlib_2d_fig.set_size_inches(4,2)
        self.matplotlib_2d_fig.set_size_inches((self.right_frame.winfo_width() / width_dpi) - 0.5,
                                               self.right_frame.winfo_height() / height_dpi)
        self.matplotlib_2d_ax = self.matplotlib_2d_fig.add_axes([.1, .1, .7, .7])
        if self.debug_print_flag:
            print("Matplotlib figsize in inches: ", (self.right_frame.winfo_width() / width_dpi) - 0.5,
                  self.right_frame.winfo_height() / height_dpi)
        self.matplotlib_2d_fig_x, self.matplotlib_2d_fig_y = 0, 0
        self.matplotlib_2d_fig_loc = (self.matplotlib_2d_fig_x, self.matplotlib_2d_fig_y)
        # fig = plt.figure()
        # ax = fig.gca(projection='3d')
        # Create a figure for 3d plotting
        self.matplotlib_3d_fig = mpl.figure.Figure()
        self.matplotlib_3d_figure_canvas_agg = FigureCanvasAgg(self.matplotlib_3d_fig)
        # self.matplotlib_2d_fig.set_size_inches(4,2)
        self.matplotlib_3d_fig.set_size_inches((self.right_frame.winfo_width() / width_dpi) - 0.5,
                                               self.right_frame.winfo_height() / height_dpi)
        self.matplotlib_3d_ax = self.matplotlib_3d_fig.add_axes([.1, .1, .6, .6], projection='3d')
        self.matplotlib_3d_fig_x, self.matplotlib_3d_fig_y = 0, 0
        self.matplotlib_3d_fig_loc = (self.matplotlib_3d_fig_x, self.matplotlib_3d_fig_y)

    def display_matplotlib_figure_on_tk_canvas(self):
        # Draw a matplotlib figure in a Tk canvas
        self.matplotlib_2d_ax.clear()
        X = np.linspace(0, 2 * np.pi, 100)
        # Y = np.sin(X)
        Y = np.sin(X * np.int((np.random.rand() + .1) * 10))
        self.matplotlib_2d_ax.plot(X, Y)
        self.matplotlib_2d_ax.set_xlim([0, 2 * np.pi])
        self.matplotlib_2d_ax.set_ylim([-1, 1])
        self.matplotlib_2d_ax.grid(True, which='both')
        self.matplotlib_2d_ax.axhline(y=0, color='k')
        self.matplotlib_2d_ax.axvline(x=0, color='k')
        # plt.subplots_adjust(left=0.0, right=1.0, bottom=0.0, top=1.0)
        # Place the matplotlib figure on canvas and display it
        self.matplotlib_2d_figure_canvas_agg = FigureCanvasAgg(self.matplotlib_2d_fig)
        self.matplotlib_2d_figure_canvas_agg.draw()
        self.matplotlib_2d_figure_x, self.matplotlib_2d_figure_y, self.matplotlib_2d_figure_w, \
        self.matplotlib_2d_figure_h = self.matplotlib_2d_fig.bbox.bounds
        self.matplotlib_2d_figure_w, self.matplotlib_2d_figure_h = int(self.matplotlib_2d_figure_w), int(
            self.matplotlib_2d_figure_h)
        self.photo = tk.PhotoImage(master=self.canvas, width=self.matplotlib_2d_figure_w,
                                   height=self.matplotlib_2d_figure_h)
        # Position: convert from top-left anchor to center anchor
        self.canvas.create_image(self.matplotlib_2d_fig_loc[0] + self.matplotlib_2d_figure_w / 2,
                                 self.matplotlib_2d_fig_loc[1] + self.matplotlib_2d_figure_h / 2, image=self.photo)
        tkagg.blit(self.photo, self.matplotlib_2d_figure_canvas_agg.get_renderer()._renderer, colormode=2)
        self.matplotlib_2d_fig_w, self.matplotlib_2d_fig_h = self.photo.width(), self.photo.height()
        self.canvas.create_text(0, 0, text="Sin Wave", anchor="nw")

    def display_matplotlib_3d_figure_on_tk_canvas(self):
        self.matplotlib_3d_ax.clear()
        r = np.linspace(0, 6, 100)
        temp = np.random.rand()
        theta = np.linspace(-temp * np.pi, temp * np.pi, 40)
        r, theta = np.meshgrid(r, theta)
        X = r * np.sin(theta)
        Y = r * np.cos(theta)
        Z = np.sin(np.sqrt(X ** 2 + Y ** 2))
        surf = self.matplotlib_3d_ax.plot_surface(X, Y, Z, rstride=1, cstride=1, cmap="coolwarm", linewidth=0,
                                                  antialiased=False);
        # surf = self.matplotlib_3d_ax.plot_surface(X, Y, Z, rcount=1, ccount=1, cmap='bwr', edgecolor='none');
        self.matplotlib_3d_ax.set_xlim(-6, 6)
        self.matplotlib_3d_ax.set_ylim(-6, 6)
        self.matplotlib_3d_ax.set_zlim(-1.01, 1.01)
        self.matplotlib_3d_ax.zaxis.set_major_locator(LinearLocator(10))
        self.matplotlib_3d_ax.zaxis.set_major_formatter(FormatStrFormatter('%.02f'))
        # Place the matplotlib figure on canvas and display it
        self.matplotlib_3d_figure_canvas_agg.draw()
        self.matplotlib_3d_figure_x, self.matplotlib_3d_figure_y, self.matplotlib_3d_figure_w, \
        self.matplotlib_3d_figure_h = self.matplotlib_2d_fig.bbox.bounds
        self.matplotlib_3d_figure_w, self.matplotlib_3d_figure_h = int(self.matplotlib_3d_figure_w), int(
            self.matplotlib_3d_figure_h)
        if self.debug_print_flag:
            print("Matplotlib 3d figure x, y, w, h: ", self.matplotlib_3d_figure_x, self.matplotlib_3d_figure_y,
                  self.matplotlib_3d_figure_w, self.matplotlib_3d_figure_h)
        self.photo = tk.PhotoImage(master=self.canvas, width=self.matplotlib_3d_figure_w,
                                   height=self.matplotlib_3d_figure_h)
        # Position: convert from top-left anchor to center anchor
        self.canvas.create_image(self.matplotlib_3d_fig_loc[0] + self.matplotlib_3d_figure_w / 2,
                                 self.matplotlib_3d_fig_loc[1] + self.matplotlib_3d_figure_h / 2, image=self.photo)
        tkagg.blit(self.photo, self.matplotlib_3d_figure_canvas_agg.get_renderer()._renderer, colormode=2)
        self.matplotlib_3d_fig_w, self.matplotlib_3d_fig_h = self.photo.width(), self.photo.height()

    def key_pressed_callback(self, event):
        self.root.status_bar.set('%s', 'Key pressed')

    def up_arrow_pressed_callback(self, event):
        self.root.status_bar.set('%s', "Up arrow was pressed")

    def down_arrow_pressed_callback(self, event):
        self.root.status_bar.set('%s', "Down arrow was pressed")

    def right_arrow_pressed_callback(self, event):
        self.root.status_bar.set('%s', "Right arrow was pressed")

    def left_arrow_pressed_callback(self, event):
        self.root.status_bar.set('%s', "Left arrow was pressed")

    def shift_up_arrow_pressed_callback(self, event):
        self.root.status_bar.set('%s', "Shift up arrow was pressed")

    def shift_down_arrow_pressed_callback(self, event):
        self.root.status_bar.set('%s', "Shift down arrow was pressed")

    def shift_right_arrow_pressed_callback(self, event):
        self.root.status_bar.set('%s', "Shift right arrow was pressed")

    def shift_left_arrow_pressed_callback(self, event):
        self.root.status_bar.set('%s', "Shift left arrow was pressed")

    def f_key_pressed_callback(self, event):
        self.root.status_bar.set('%s', "f key was pressed")

    def b_key_pressed_callback(self, event):
        self.root.status_bar.set('%s', "b key was pressed")

    def left_mouse_click_callback(self, event):
        self.root.status_bar.set('%s', 'Left mouse button was clicked. ' + 'x=' + str(event.x) + '   y=' + str(
            event.y))
        self.x = event.x
        self.y = event.y
        self.canvas.focus_set()

    def left_mouse_release_callback(self, event):
        self.root.status_bar.set('%s',
                                 'Left mouse button was released. ' + 'x=' + str(event.x) + '   y=' + str(event.y))
        self.x = None
        self.y = None

    def left_mouse_down_motion_callback(self, event):
        self.root.status_bar.set('%s', 'Left mouse down motion. ' + 'x=' + str(event.x) + '   y=' + str(event.y))
        self.x = event.x
        self.y = event.y

    def right_mouse_click_callback(self, event):
        self.root.status_bar.set('%s', 'Right mouse down motion. ' + 'x=' + str(event.x) + '   y=' + str(event.y))
        self.x = event.x
        self.y = event.y

    def right_mouse_release_callback(self, event):
        self.root.status_bar.set('%s',
                                 'Right mouse button was released. ' + 'x=' + str(event.x) + '   y=' + str(event.y))
        self.x = None
        self.y = None

    def right_mouse_down_motion_callback(self, event):
        self.root.status_bar.set('%s', 'Right mouse down motion. ' + 'x=' + str(event.x) + '   y=' + str(event.y))
        self.x = event.x
        self.y = event.y

    def left_mouse_click_callback(self, event):
        self.root.status_bar.set('%s', 'Left mouse button was clicked. ' + 'x=' + str(event.x) + '   y=' + str(
            event.y))
        self.x = event.x
        self.y = event.y

    # self.focus_set()
    def frame_resized_callback(self, event):
        print("frame resize callback")

    def create_graphic_objects(self):
        self.canvas.delete("all")
        r = np.random.rand()
        self.drawing_objects = []
        for scale in np.linspace(.1, 0.8, 20):
            self.drawing_objects.append(self.canvas.create_oval(int(scale * int(self.canvas.cget("width"))),
                                                                int(r * int(self.canvas.cget("height"))),
                                                                int((1 - scale) * int(self.canvas.cget("width"))),
                                                                int((1 - scale) * int(self.canvas.cget("height")))))

    def redisplay(self, event):
        self.create_graphic_objects()

    def matplotlib_plot_2d_callback(self):
        self.display_matplotlib_figure_on_tk_canvas()
        self.root.status_bar.set('%s', "called matplotlib_plot_2d_callback callback!")

    def matplotlib_plot_3d_callback(self):
        self.display_matplotlib_3d_figure_on_tk_canvas()
        self.root.status_bar.set('%s', "called matplotlib_plot_3d_callback callback!")

    def graphics_draw_callback(self):
        self.create_graphic_objects()
        self.root.status_bar.set('%s', "called the draw callback!")


def close_window_callback(root):
    if tk.messagebox.askokcancel("Quit", "Do you really wish to quit?"):
        root.destroy()


main_window = MainWindow(debug_print_flag=False)
# main_window.geometry("500x500")
main_window.wm_state('zoomed')
main_window.title('Assignment_04 --  Shinde')
main_window.minsize(800, 600)
main_window.protocol("WM_DELETE_WINDOW", lambda root_window=main_window: close_window_callback(root_window))
main_window.mainloop()
